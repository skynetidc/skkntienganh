<?php

if (! defined('PAYOS_PAYMENT_METHOD_NAME')) {
    define('PAYOS_PAYMENT_METHOD_NAME', 'payos');
}
