<?php

namespace PayOs\Http\Requests;

use Support\Http\Requests\Request;

class PayOsPaymentCallbackRequest extends Request
{
    public function rules(): array
    {
        return [];
    }
}
