<?php

namespace Binjuhor\PayOs\Http\Requests;

use Botble\Support\Http\Requests\Request;

class PayOsPaymentCallbackRequest extends Request
{
    public function rules(): array
    {
        return [];
    }
}
