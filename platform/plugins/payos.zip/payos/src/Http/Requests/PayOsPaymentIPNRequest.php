<?php

namespace PayOs\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PayOsPaymentIPNRequest extends FormRequest
{
    public function rules(): array
    {
        return [];
    }
}
