<strong>{{ trans('plugins/payos::payos.payment_details') }}: </strong>
@include('plugins/payos::detail', compact('payment'))
